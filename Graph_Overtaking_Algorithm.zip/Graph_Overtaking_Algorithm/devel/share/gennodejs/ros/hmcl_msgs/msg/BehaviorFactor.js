// Auto-generated. Do not edit!

// (in-package hmcl_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let std_msgs = _finder('std_msgs');

//-----------------------------------------------------------

class BehaviorFactor {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.header = null;
      this.front_vel = null;
      this.xObstacle = null;
      this.yObstacle = null;
      this.front_dist = null;
      this.sEgo = null;
      this.lEgo = null;
      this.sObj = null;
      this.lObj = null;
      this.dsObj = null;
      this.dlObj = null;
      this.prefer_lane_id = null;
      this.current_lane_id = null;
      this.missionStart = null;
      this.missionEnd = null;
      this.frontOpponent = null;
      this.stationaryFrontOpponent = null;
      this.trafficLightStop = null;
      this.stopCheck = null;
      this.laneChangeDone = null;
      this.isInBank = null;
    }
    else {
      if (initObj.hasOwnProperty('header')) {
        this.header = initObj.header
      }
      else {
        this.header = new std_msgs.msg.Header();
      }
      if (initObj.hasOwnProperty('front_vel')) {
        this.front_vel = initObj.front_vel
      }
      else {
        this.front_vel = 0.0;
      }
      if (initObj.hasOwnProperty('xObstacle')) {
        this.xObstacle = initObj.xObstacle
      }
      else {
        this.xObstacle = 0.0;
      }
      if (initObj.hasOwnProperty('yObstacle')) {
        this.yObstacle = initObj.yObstacle
      }
      else {
        this.yObstacle = 0.0;
      }
      if (initObj.hasOwnProperty('front_dist')) {
        this.front_dist = initObj.front_dist
      }
      else {
        this.front_dist = 0.0;
      }
      if (initObj.hasOwnProperty('sEgo')) {
        this.sEgo = initObj.sEgo
      }
      else {
        this.sEgo = 0.0;
      }
      if (initObj.hasOwnProperty('lEgo')) {
        this.lEgo = initObj.lEgo
      }
      else {
        this.lEgo = 0.0;
      }
      if (initObj.hasOwnProperty('sObj')) {
        this.sObj = initObj.sObj
      }
      else {
        this.sObj = [];
      }
      if (initObj.hasOwnProperty('lObj')) {
        this.lObj = initObj.lObj
      }
      else {
        this.lObj = [];
      }
      if (initObj.hasOwnProperty('dsObj')) {
        this.dsObj = initObj.dsObj
      }
      else {
        this.dsObj = [];
      }
      if (initObj.hasOwnProperty('dlObj')) {
        this.dlObj = initObj.dlObj
      }
      else {
        this.dlObj = [];
      }
      if (initObj.hasOwnProperty('prefer_lane_id')) {
        this.prefer_lane_id = initObj.prefer_lane_id
      }
      else {
        this.prefer_lane_id = 0;
      }
      if (initObj.hasOwnProperty('current_lane_id')) {
        this.current_lane_id = initObj.current_lane_id
      }
      else {
        this.current_lane_id = 0;
      }
      if (initObj.hasOwnProperty('missionStart')) {
        this.missionStart = initObj.missionStart
      }
      else {
        this.missionStart = false;
      }
      if (initObj.hasOwnProperty('missionEnd')) {
        this.missionEnd = initObj.missionEnd
      }
      else {
        this.missionEnd = false;
      }
      if (initObj.hasOwnProperty('frontOpponent')) {
        this.frontOpponent = initObj.frontOpponent
      }
      else {
        this.frontOpponent = false;
      }
      if (initObj.hasOwnProperty('stationaryFrontOpponent')) {
        this.stationaryFrontOpponent = initObj.stationaryFrontOpponent
      }
      else {
        this.stationaryFrontOpponent = false;
      }
      if (initObj.hasOwnProperty('trafficLightStop')) {
        this.trafficLightStop = initObj.trafficLightStop
      }
      else {
        this.trafficLightStop = false;
      }
      if (initObj.hasOwnProperty('stopCheck')) {
        this.stopCheck = initObj.stopCheck
      }
      else {
        this.stopCheck = false;
      }
      if (initObj.hasOwnProperty('laneChangeDone')) {
        this.laneChangeDone = initObj.laneChangeDone
      }
      else {
        this.laneChangeDone = false;
      }
      if (initObj.hasOwnProperty('isInBank')) {
        this.isInBank = initObj.isInBank
      }
      else {
        this.isInBank = false;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type BehaviorFactor
    // Serialize message field [header]
    bufferOffset = std_msgs.msg.Header.serialize(obj.header, buffer, bufferOffset);
    // Serialize message field [front_vel]
    bufferOffset = _serializer.float32(obj.front_vel, buffer, bufferOffset);
    // Serialize message field [xObstacle]
    bufferOffset = _serializer.float32(obj.xObstacle, buffer, bufferOffset);
    // Serialize message field [yObstacle]
    bufferOffset = _serializer.float32(obj.yObstacle, buffer, bufferOffset);
    // Serialize message field [front_dist]
    bufferOffset = _serializer.float32(obj.front_dist, buffer, bufferOffset);
    // Serialize message field [sEgo]
    bufferOffset = _serializer.float32(obj.sEgo, buffer, bufferOffset);
    // Serialize message field [lEgo]
    bufferOffset = _serializer.float32(obj.lEgo, buffer, bufferOffset);
    // Serialize message field [sObj]
    bufferOffset = _arraySerializer.float32(obj.sObj, buffer, bufferOffset, null);
    // Serialize message field [lObj]
    bufferOffset = _arraySerializer.float32(obj.lObj, buffer, bufferOffset, null);
    // Serialize message field [dsObj]
    bufferOffset = _arraySerializer.float32(obj.dsObj, buffer, bufferOffset, null);
    // Serialize message field [dlObj]
    bufferOffset = _arraySerializer.float32(obj.dlObj, buffer, bufferOffset, null);
    // Serialize message field [prefer_lane_id]
    bufferOffset = _serializer.int64(obj.prefer_lane_id, buffer, bufferOffset);
    // Serialize message field [current_lane_id]
    bufferOffset = _serializer.int64(obj.current_lane_id, buffer, bufferOffset);
    // Serialize message field [missionStart]
    bufferOffset = _serializer.bool(obj.missionStart, buffer, bufferOffset);
    // Serialize message field [missionEnd]
    bufferOffset = _serializer.bool(obj.missionEnd, buffer, bufferOffset);
    // Serialize message field [frontOpponent]
    bufferOffset = _serializer.bool(obj.frontOpponent, buffer, bufferOffset);
    // Serialize message field [stationaryFrontOpponent]
    bufferOffset = _serializer.bool(obj.stationaryFrontOpponent, buffer, bufferOffset);
    // Serialize message field [trafficLightStop]
    bufferOffset = _serializer.bool(obj.trafficLightStop, buffer, bufferOffset);
    // Serialize message field [stopCheck]
    bufferOffset = _serializer.bool(obj.stopCheck, buffer, bufferOffset);
    // Serialize message field [laneChangeDone]
    bufferOffset = _serializer.bool(obj.laneChangeDone, buffer, bufferOffset);
    // Serialize message field [isInBank]
    bufferOffset = _serializer.bool(obj.isInBank, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type BehaviorFactor
    let len;
    let data = new BehaviorFactor(null);
    // Deserialize message field [header]
    data.header = std_msgs.msg.Header.deserialize(buffer, bufferOffset);
    // Deserialize message field [front_vel]
    data.front_vel = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [xObstacle]
    data.xObstacle = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [yObstacle]
    data.yObstacle = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [front_dist]
    data.front_dist = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [sEgo]
    data.sEgo = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [lEgo]
    data.lEgo = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [sObj]
    data.sObj = _arrayDeserializer.float32(buffer, bufferOffset, null)
    // Deserialize message field [lObj]
    data.lObj = _arrayDeserializer.float32(buffer, bufferOffset, null)
    // Deserialize message field [dsObj]
    data.dsObj = _arrayDeserializer.float32(buffer, bufferOffset, null)
    // Deserialize message field [dlObj]
    data.dlObj = _arrayDeserializer.float32(buffer, bufferOffset, null)
    // Deserialize message field [prefer_lane_id]
    data.prefer_lane_id = _deserializer.int64(buffer, bufferOffset);
    // Deserialize message field [current_lane_id]
    data.current_lane_id = _deserializer.int64(buffer, bufferOffset);
    // Deserialize message field [missionStart]
    data.missionStart = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [missionEnd]
    data.missionEnd = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [frontOpponent]
    data.frontOpponent = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [stationaryFrontOpponent]
    data.stationaryFrontOpponent = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [trafficLightStop]
    data.trafficLightStop = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [stopCheck]
    data.stopCheck = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [laneChangeDone]
    data.laneChangeDone = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [isInBank]
    data.isInBank = _deserializer.bool(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += std_msgs.msg.Header.getMessageSize(object.header);
    length += 4 * object.sObj.length;
    length += 4 * object.lObj.length;
    length += 4 * object.dsObj.length;
    length += 4 * object.dlObj.length;
    return length + 64;
  }

  static datatype() {
    // Returns string type for a message object
    return 'hmcl_msgs/BehaviorFactor';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'd2a8f70025e3a07bde8bfaa8bae1297c';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    Header header
    float32 front_vel
    float32 xObstacle
    float32 yObstacle
    float32 front_dist
    float32 sEgo
    float32 lEgo
    float32[] sObj
    float32[] lObj
    float32[] dsObj
    float32[] dlObj
    int64 prefer_lane_id
    int64 current_lane_id
    bool missionStart
    bool missionEnd
    bool frontOpponent
    bool stationaryFrontOpponent
    bool trafficLightStop
    bool stopCheck
    bool laneChangeDone
    bool isInBank
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    string frame_id
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new BehaviorFactor(null);
    if (msg.header !== undefined) {
      resolved.header = std_msgs.msg.Header.Resolve(msg.header)
    }
    else {
      resolved.header = new std_msgs.msg.Header()
    }

    if (msg.front_vel !== undefined) {
      resolved.front_vel = msg.front_vel;
    }
    else {
      resolved.front_vel = 0.0
    }

    if (msg.xObstacle !== undefined) {
      resolved.xObstacle = msg.xObstacle;
    }
    else {
      resolved.xObstacle = 0.0
    }

    if (msg.yObstacle !== undefined) {
      resolved.yObstacle = msg.yObstacle;
    }
    else {
      resolved.yObstacle = 0.0
    }

    if (msg.front_dist !== undefined) {
      resolved.front_dist = msg.front_dist;
    }
    else {
      resolved.front_dist = 0.0
    }

    if (msg.sEgo !== undefined) {
      resolved.sEgo = msg.sEgo;
    }
    else {
      resolved.sEgo = 0.0
    }

    if (msg.lEgo !== undefined) {
      resolved.lEgo = msg.lEgo;
    }
    else {
      resolved.lEgo = 0.0
    }

    if (msg.sObj !== undefined) {
      resolved.sObj = msg.sObj;
    }
    else {
      resolved.sObj = []
    }

    if (msg.lObj !== undefined) {
      resolved.lObj = msg.lObj;
    }
    else {
      resolved.lObj = []
    }

    if (msg.dsObj !== undefined) {
      resolved.dsObj = msg.dsObj;
    }
    else {
      resolved.dsObj = []
    }

    if (msg.dlObj !== undefined) {
      resolved.dlObj = msg.dlObj;
    }
    else {
      resolved.dlObj = []
    }

    if (msg.prefer_lane_id !== undefined) {
      resolved.prefer_lane_id = msg.prefer_lane_id;
    }
    else {
      resolved.prefer_lane_id = 0
    }

    if (msg.current_lane_id !== undefined) {
      resolved.current_lane_id = msg.current_lane_id;
    }
    else {
      resolved.current_lane_id = 0
    }

    if (msg.missionStart !== undefined) {
      resolved.missionStart = msg.missionStart;
    }
    else {
      resolved.missionStart = false
    }

    if (msg.missionEnd !== undefined) {
      resolved.missionEnd = msg.missionEnd;
    }
    else {
      resolved.missionEnd = false
    }

    if (msg.frontOpponent !== undefined) {
      resolved.frontOpponent = msg.frontOpponent;
    }
    else {
      resolved.frontOpponent = false
    }

    if (msg.stationaryFrontOpponent !== undefined) {
      resolved.stationaryFrontOpponent = msg.stationaryFrontOpponent;
    }
    else {
      resolved.stationaryFrontOpponent = false
    }

    if (msg.trafficLightStop !== undefined) {
      resolved.trafficLightStop = msg.trafficLightStop;
    }
    else {
      resolved.trafficLightStop = false
    }

    if (msg.stopCheck !== undefined) {
      resolved.stopCheck = msg.stopCheck;
    }
    else {
      resolved.stopCheck = false
    }

    if (msg.laneChangeDone !== undefined) {
      resolved.laneChangeDone = msg.laneChangeDone;
    }
    else {
      resolved.laneChangeDone = false
    }

    if (msg.isInBank !== undefined) {
      resolved.isInBank = msg.isInBank;
    }
    else {
      resolved.isInBank = false
    }

    return resolved;
    }
};

module.exports = BehaviorFactor;
