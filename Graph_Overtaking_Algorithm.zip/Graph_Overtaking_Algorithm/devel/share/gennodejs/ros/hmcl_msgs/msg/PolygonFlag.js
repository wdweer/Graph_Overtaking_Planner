// Auto-generated. Do not edit!

// (in-package hmcl_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let std_msgs = _finder('std_msgs');

//-----------------------------------------------------------

class PolygonFlag {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.header = null;
      this.isinJunction = null;
      this.isinExit = null;
      this.isinBank = null;
      this.isinFreespace = null;
      this.isinCrosswalk = null;
      this.isinStopline = null;
      this.isinParking = null;
      this.isinTrafficIsland = null;
    }
    else {
      if (initObj.hasOwnProperty('header')) {
        this.header = initObj.header
      }
      else {
        this.header = new std_msgs.msg.Header();
      }
      if (initObj.hasOwnProperty('isinJunction')) {
        this.isinJunction = initObj.isinJunction
      }
      else {
        this.isinJunction = false;
      }
      if (initObj.hasOwnProperty('isinExit')) {
        this.isinExit = initObj.isinExit
      }
      else {
        this.isinExit = false;
      }
      if (initObj.hasOwnProperty('isinBank')) {
        this.isinBank = initObj.isinBank
      }
      else {
        this.isinBank = false;
      }
      if (initObj.hasOwnProperty('isinFreespace')) {
        this.isinFreespace = initObj.isinFreespace
      }
      else {
        this.isinFreespace = false;
      }
      if (initObj.hasOwnProperty('isinCrosswalk')) {
        this.isinCrosswalk = initObj.isinCrosswalk
      }
      else {
        this.isinCrosswalk = false;
      }
      if (initObj.hasOwnProperty('isinStopline')) {
        this.isinStopline = initObj.isinStopline
      }
      else {
        this.isinStopline = false;
      }
      if (initObj.hasOwnProperty('isinParking')) {
        this.isinParking = initObj.isinParking
      }
      else {
        this.isinParking = false;
      }
      if (initObj.hasOwnProperty('isinTrafficIsland')) {
        this.isinTrafficIsland = initObj.isinTrafficIsland
      }
      else {
        this.isinTrafficIsland = false;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type PolygonFlag
    // Serialize message field [header]
    bufferOffset = std_msgs.msg.Header.serialize(obj.header, buffer, bufferOffset);
    // Serialize message field [isinJunction]
    bufferOffset = _serializer.bool(obj.isinJunction, buffer, bufferOffset);
    // Serialize message field [isinExit]
    bufferOffset = _serializer.bool(obj.isinExit, buffer, bufferOffset);
    // Serialize message field [isinBank]
    bufferOffset = _serializer.bool(obj.isinBank, buffer, bufferOffset);
    // Serialize message field [isinFreespace]
    bufferOffset = _serializer.bool(obj.isinFreespace, buffer, bufferOffset);
    // Serialize message field [isinCrosswalk]
    bufferOffset = _serializer.bool(obj.isinCrosswalk, buffer, bufferOffset);
    // Serialize message field [isinStopline]
    bufferOffset = _serializer.bool(obj.isinStopline, buffer, bufferOffset);
    // Serialize message field [isinParking]
    bufferOffset = _serializer.bool(obj.isinParking, buffer, bufferOffset);
    // Serialize message field [isinTrafficIsland]
    bufferOffset = _serializer.bool(obj.isinTrafficIsland, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type PolygonFlag
    let len;
    let data = new PolygonFlag(null);
    // Deserialize message field [header]
    data.header = std_msgs.msg.Header.deserialize(buffer, bufferOffset);
    // Deserialize message field [isinJunction]
    data.isinJunction = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [isinExit]
    data.isinExit = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [isinBank]
    data.isinBank = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [isinFreespace]
    data.isinFreespace = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [isinCrosswalk]
    data.isinCrosswalk = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [isinStopline]
    data.isinStopline = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [isinParking]
    data.isinParking = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [isinTrafficIsland]
    data.isinTrafficIsland = _deserializer.bool(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += std_msgs.msg.Header.getMessageSize(object.header);
    return length + 8;
  }

  static datatype() {
    // Returns string type for a message object
    return 'hmcl_msgs/PolygonFlag';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '4fa9b7208f05393943c0566bcd920f29';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    Header header
    bool isinJunction
    bool isinExit
    bool isinBank
    bool isinFreespace
    bool isinCrosswalk
    bool isinStopline
    bool isinParking
    bool isinTrafficIsland
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    string frame_id
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new PolygonFlag(null);
    if (msg.header !== undefined) {
      resolved.header = std_msgs.msg.Header.Resolve(msg.header)
    }
    else {
      resolved.header = new std_msgs.msg.Header()
    }

    if (msg.isinJunction !== undefined) {
      resolved.isinJunction = msg.isinJunction;
    }
    else {
      resolved.isinJunction = false
    }

    if (msg.isinExit !== undefined) {
      resolved.isinExit = msg.isinExit;
    }
    else {
      resolved.isinExit = false
    }

    if (msg.isinBank !== undefined) {
      resolved.isinBank = msg.isinBank;
    }
    else {
      resolved.isinBank = false
    }

    if (msg.isinFreespace !== undefined) {
      resolved.isinFreespace = msg.isinFreespace;
    }
    else {
      resolved.isinFreespace = false
    }

    if (msg.isinCrosswalk !== undefined) {
      resolved.isinCrosswalk = msg.isinCrosswalk;
    }
    else {
      resolved.isinCrosswalk = false
    }

    if (msg.isinStopline !== undefined) {
      resolved.isinStopline = msg.isinStopline;
    }
    else {
      resolved.isinStopline = false
    }

    if (msg.isinParking !== undefined) {
      resolved.isinParking = msg.isinParking;
    }
    else {
      resolved.isinParking = false
    }

    if (msg.isinTrafficIsland !== undefined) {
      resolved.isinTrafficIsland = msg.isinTrafficIsland;
    }
    else {
      resolved.isinTrafficIsland = false
    }

    return resolved;
    }
};

module.exports = PolygonFlag;
