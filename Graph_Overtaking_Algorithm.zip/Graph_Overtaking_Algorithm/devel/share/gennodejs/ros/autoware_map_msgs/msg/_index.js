
"use strict";

let WaypointLaneRelation = require('./WaypointLaneRelation.js');
let OppositeLaneRelationArray = require('./OppositeLaneRelationArray.js');
let LaneAttributeRelationArray = require('./LaneAttributeRelationArray.js');
let Waypoint = require('./Waypoint.js');
let WaypointArray = require('./WaypointArray.js');
let WaypointRelationArray = require('./WaypointRelationArray.js');
let SignalLight = require('./SignalLight.js');
let WaypointSignalRelationArray = require('./WaypointSignalRelationArray.js');
let WaypointLaneRelationArray = require('./WaypointLaneRelationArray.js');
let Signal = require('./Signal.js');
let PointArray = require('./PointArray.js');
let LaneSignalLightRelationArray = require('./LaneSignalLightRelationArray.js');
let Area = require('./Area.js');
let Point = require('./Point.js');
let LaneSignalLightRelation = require('./LaneSignalLightRelation.js');
let LaneRelation = require('./LaneRelation.js');
let LaneChangeRelation = require('./LaneChangeRelation.js');
let LaneRelationArray = require('./LaneRelationArray.js');
let SignalArray = require('./SignalArray.js');
let WayareaArray = require('./WayareaArray.js');
let Wayarea = require('./Wayarea.js');
let LaneAttributeRelation = require('./LaneAttributeRelation.js');
let Lane = require('./Lane.js');
let SignalLightArray = require('./SignalLightArray.js');
let AreaArray = require('./AreaArray.js');
let WaypointRelation = require('./WaypointRelation.js');
let LaneChangeRelationArray = require('./LaneChangeRelationArray.js');
let OppositeLaneRelation = require('./OppositeLaneRelation.js');
let LaneArray = require('./LaneArray.js');
let WaypointSignalRelation = require('./WaypointSignalRelation.js');

module.exports = {
  WaypointLaneRelation: WaypointLaneRelation,
  OppositeLaneRelationArray: OppositeLaneRelationArray,
  LaneAttributeRelationArray: LaneAttributeRelationArray,
  Waypoint: Waypoint,
  WaypointArray: WaypointArray,
  WaypointRelationArray: WaypointRelationArray,
  SignalLight: SignalLight,
  WaypointSignalRelationArray: WaypointSignalRelationArray,
  WaypointLaneRelationArray: WaypointLaneRelationArray,
  Signal: Signal,
  PointArray: PointArray,
  LaneSignalLightRelationArray: LaneSignalLightRelationArray,
  Area: Area,
  Point: Point,
  LaneSignalLightRelation: LaneSignalLightRelation,
  LaneRelation: LaneRelation,
  LaneChangeRelation: LaneChangeRelation,
  LaneRelationArray: LaneRelationArray,
  SignalArray: SignalArray,
  WayareaArray: WayareaArray,
  Wayarea: Wayarea,
  LaneAttributeRelation: LaneAttributeRelation,
  Lane: Lane,
  SignalLightArray: SignalLightArray,
  AreaArray: AreaArray,
  WaypointRelation: WaypointRelation,
  LaneChangeRelationArray: LaneChangeRelationArray,
  OppositeLaneRelation: OppositeLaneRelation,
  LaneArray: LaneArray,
  WaypointSignalRelation: WaypointSignalRelation,
};
